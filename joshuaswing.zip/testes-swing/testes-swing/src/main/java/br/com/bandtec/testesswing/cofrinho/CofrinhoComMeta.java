
package br.com.bandtec.testesswing.cofrinho;


public class CofrinhoComMeta {
    private Double total = 0.0;
    private Double meta;

    public void setMeta(Double meta) {
        if (meta > 0) {
            this.meta = meta;
        }
    }

    public Double getMeta() {
        return meta;
    }
    
    public Double getTotal() {
        return total;
    }

    public void depositar(Double valorDeposito) {
        if (valorDeposito>0) {
            if (meta > total) {
                this.total += valorDeposito;
            }        
        }
    }
    
    public String getTextoMeta() {
        String texto;
        
        if (meta == null) {
            texto = "Meta ainda não definida!";
        } else {
            texto = meta <= total ?
                    "Parabéns! Meta alcançada!" :
                    "Ainda falta "+(meta-total)+" para a meta";
        }
        
        return texto;
    }
    
    
    
}
