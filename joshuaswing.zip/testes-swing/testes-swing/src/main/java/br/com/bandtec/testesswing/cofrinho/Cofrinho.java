
package br.com.bandtec.testesswing.cofrinho;


public class Cofrinho {
    private Double total = 0.0;
   
    public Double getTotal() {
        return total;
    }

    public void depositar(Double valorDeposito) {
        if (valorDeposito>0) {
            this.total += valorDeposito;
        }
    }
    
}
