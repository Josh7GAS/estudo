package aulareforco;

public class Cofrinho {

    protected double total = 0;
    protected int depositos = 0;
    protected String nome;

    public Cofrinho() {
        
    }

    Cofrinho(String nomeCofrinho) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Cofrinho (String nome, double total){
    this.nome=nome;
    this.total = total;
    }
    public double getTotal() {
        return total;
    }

    // para depositar, informamos o valor do depósito
    public void depositar(double valorDeposito) {
        if (depositos <= 5) {
            total += valorDeposito;
            depositos++;
        }
    }

    // para sacar, informado o valor do saque
    public void sacar(double valorSaque) {
        total -= valorSaque;

        if (total < 0) {
            total = 0;
        }
    }
}
