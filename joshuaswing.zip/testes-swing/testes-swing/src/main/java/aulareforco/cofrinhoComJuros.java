/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulareforco;

/**
 *
 * @author Aluno
 */
public class cofrinhoComJuros extends Cofrinho {

    private double juros;

    //contrutor nunca é heradado
    public cofrinhoComJuros(String nome, double total, double juros) {
        super(nome, total);
        this.juros = juros;
    }
    @Override
    public void depositar(double valorDeposito){
    if (depositos <4){
    total += valorDeposito;
    depositos++;
    }
    }

}
